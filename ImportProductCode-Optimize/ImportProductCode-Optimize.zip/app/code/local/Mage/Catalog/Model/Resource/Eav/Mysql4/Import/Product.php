<?php

class Mage_Catalog_Model_Resource_Eav_Mysql4_Import_Product extends Mage_Catalog_Model_Resource_Import_Product
{
}

?>